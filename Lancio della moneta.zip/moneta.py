# Copyright (C) 2025 Francesco Piroddi
# Questo programma è distribuito con la licenza GNU General Public License v3.0

import random

def lancia_moneta():
    # Lista con le due opzioni possibili
    opzioni = ["Tempo di giocare", "Tempo di riposare"]
    
    # Scegli un'opzione casuale
    risultato = random.choice(opzioni)
    
    return risultato

# Esegui il lancio della moneta
risultato_lancio = lancia_moneta()
print("Risultato del lancio:", risultato_lancio)
